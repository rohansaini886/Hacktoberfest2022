package com.springrest.bootrestbook.services;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.springrest.bootrestbook.entities.Book;

import org.springframework.stereotype.Service;

@Service
public class BookService {

    private static List<Book> list = new ArrayList<>();
    static {
        list.add(new Book(100, "Harry Potter", "JK Rowling"));
        list.add(new Book(101, "The Shiva Trilogy", "Amish Tripathi"));
        list.add(new Book(102, "The 5 AM Club", "Robin Sharma"));
    }

    // get all books
    public List<Book> getAllBooks() {
        return list;
    }

    // get single book
    public Book getBookById(int id) {
        Book book = null;

        // using stream to filter and find the first occurence of matching book details
        // according to id
        book = list.stream().filter(e -> e.getId() == id).findFirst().get();
        return book;
    }

    // add book
    public Book addBook(Book b) {
        list.add(b);
        return b;
    }

    // delete book
    public void deleteBook(int id) {
        list = list.stream().filter(book -> book.getId() != id).collect(Collectors.toList());
    }

    // update book
    public void updateBook(Book book, int bookId) {
        list.stream().map(b -> {
            if (b.getId() == bookId) {
                b.setTitle(book.getTitle());
                b.setAuthor(book.getAuthor());
            }
            return b;
        }).collect(Collectors.toList());
    }
}
